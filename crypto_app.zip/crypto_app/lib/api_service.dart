import 'dart:convert';
import 'package:http/http.dart' as http;
import 'crypto_model.dart';

class ApiService {
  final String apiUrl = "https://api.coinlore.net/api/tickers/";

  Future<List<Crypto>> fetchCryptos() async {
    final response = await http.get(Uri.parse(apiUrl));

    if (response.statusCode == 200) {
      final List<dynamic> data = jsonDecode(response.body)['data'];
      List<Crypto> cryptos =
          data.map((crypto) => Crypto.fromJson(crypto)).toList();
      cryptos.sort((a, b) => a.name.compareTo(b.name)); // Sort by name
      return cryptos;
    } else {
      throw Exception('Failed to load cryptos');
    }
  }
}
